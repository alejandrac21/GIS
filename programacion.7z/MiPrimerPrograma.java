public class MiPrimerPrograma{
	public static void sumar (int a, int b){
		System.out.println(a+b);
	}
	public static int suma (int a, int b){
		return a+b;
	}
	public static void main (String args[] ){
		sumar (5,7);
		System.out.println (suma (6,6));	
	}
}	
